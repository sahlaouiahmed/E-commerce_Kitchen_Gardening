function addToCart() {
    // Add to cart functionality to be added later
    alert('Product added to cart (functionality to be implemented)');
}

